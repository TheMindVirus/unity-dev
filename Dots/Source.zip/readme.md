# Dots - CableSim Vertex/Fragment Shader

### Best viewed in Chrome, Edge may run slower
Demo: https://themindvirus.github.io/unity-dev/Dots

![screenshot](/Dots/cablesim.png)